import base64
import json
import os
import random
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class Session:
    def __init__(self, user, user_key, key):
        # Información del usuario
        self.user = user
        # Fernet key de la sesión de usuario
        self.session_key = key
        # Se genera al iniciar la sesión de usuario
        self.public_key = user_key.get("Public_key")
        self.private_key = user_key.get("Private_key")
        self.certificate = user_key.get("Certificate")
        self.certificate_1 = user_key.get("Cert_Level_1")
        self.certificate_2 = user_key.get("Cert_Level_2")

    def session_on(self):
        # Se inicia la sesión
        session_on = True
        # Se muestran todos los mensajes que tenga el usuarion
        for i in self.user.get("Messages"):
            print("%s" % i)
            self.user.get("Messages").remove(i)
        while session_on:
            # Se le pide que escoja una opción
            app_option = input("Search/Storage/Buy/Close: ")
            if app_option == "Search":
                # El usuario busca piedras
                self.search()
            elif app_option == "Storage":
                # El usuario accede a su almacén
                self.storage()
            elif app_option == "Buy":
                # El usuario va a comprar piedras
                self.buy()
            elif app_option == "Close":
                # Cierra la aplicación
                session_on = False
                # Se abre el JSON
                usuarios = self.open_json('users_info.json')

                # Se guardan los datos actualizados del usuario
                self.update_from_json(usuarios, self.user)
                self.update_json('users_info.json', usuarios)
                print("Se ha cerrado la sesión correctamente")
            else:
                # La opción que ha escogido no es válida
                print("Error: opción invalida. Prueba a escribir los caracteres correctamente")

    def search(self):
        # La funcion de search busca entre varios tipos de gemas dependiendo de su rareza
        rarity = random.randint(0, 149)
        if rarity >= 0 and rarity < 50:
            minerals = ["Cuarzo", "Onice", "Pirita"]
            price = random.randint(10, 25)
        elif rarity >= 50 and rarity < 90:
            minerals = ["Aguamarina", "Lapislazuli", "Obsidiana", "Opalo", "Peridoto"]
            price = random.randint(25, 50)
        elif rarity >= 90 and rarity < 120:
            minerals = ["Bismuto", "Granate", "Jade", "Topacio"]
            price = random.randint(50, 100)
        elif rarity >= 120 and rarity < 135:
            minerals = ["Amatista", "Esmeralda", "Rubi", "Zafiro"]
            price = random.randint(100, 200)
        else:
            minerals = ["Diamante", "Oro"]
            price = random.randint(200, 400)

        stone = {
            "Type": random.choice(minerals),
            "Value": price
        }
        self.user.get("Storage").append(stone)
        print("Has encontrado %s, con valor de %s!!!" % (stone.get("Type"), stone.get("Value")))

    def storage(self):
        # Se entra en un bucle de uso de almacen y se muestra el almacen
        storage_on = True
        while storage_on:
            storage = self.user.get("Storage")
            shop = self.user.get("Shop")
            usuario = self.user.get("Usuario")
            money = self.user.get("Money")
            print("-------------------------------")
            print("ALMACEN DE", usuario)
            print("-------------------------------")
            n = 0
            for item in storage:
                n += 1
                print("%d" % n + f" - {item['Type']} : {item['Value']}")
            print()
            print("--------------------------------")
            print("TIENDA DE", usuario, "DINERO = ", money)
            print("--------------------------------")
            n = 0
            for item in shop:
                n += 1
                print("%d" % n + f" - {item['Type']} : {item['Value']}")
            print()

            print("ONCE THE ITEM IS IN THE SHOP THERE'S NO GOING BACK FOR IT!")
            print
            storage_option = input("Sell/Close: ")
            # Se accede a la opcion de venta
            if storage_option == "Sell":
                self.sell(storage)
            elif storage_option == "Close":
                storage_on = False
    def buy(self):
        usuarios = self.open_json('users_info.json')
        money = self.user.get("Money")
        print("Available Users:")
        # Nos aseguramos de que nos se muestra al usuario para que no se pueda comprar a el mismo
        for usuario in usuarios:
            if usuario.get('Usuario') != self.user.get('Usuario'):
                print(f"- {usuario['Usuario']}")

        user_found = False
        selected_user = None

        # Entra en un bucle en el que pregunta a que usuario quiere comprar y le busca
        while not user_found:
            nombre_usuario = self.send_message(input("Type the name of the user whose Shop you want to see (Type Close to end the buying action): "))

            if nombre_usuario == "Close":
                return

            for usuario in usuarios:
                if usuario['Usuario'].lower() == nombre_usuario.lower():
                    if not usuario['Shop']:
                        empty = self.send_message(f"{usuario['Usuario']}'s shop is empty. Please, choose another user.")
                        print(empty)
                        selected_user = usuario
                    else:
                        selected_user = usuario
                        user_found = True

            if not user_found and not selected_user:
                exception = self.send_message("User not found. Try again.")
                print(exception)

        # Muestra la tienda del usuario
        print(f"Items on {selected_user['Usuario']}'s shop:")
        for i, item in enumerate(selected_user['Shop'], 1):
            print(f"{i}. {item['Type']} - {item['Value']} coins")
        print(f"Your current balance is: ", money)

        # Pregunta por el item a comprar y muestra la tienda del vendedor
        buying_item = self.send_message(input("Which item would you like to buy (insert the number of the item on the list): "))
        buying_item = int(buying_item)

        for i, item in enumerate(selected_user['Shop'], 1):
            if i == buying_item:
                if money >= item['Value']:
                    question = self.send_message(str(f"Would you like to buy: {item['Type']} for {item['Value']} coins? "))
                    print(question)
                    answer = self.send_message(input("Yes/No: "))
                    # Pregunta al usuario si quiere comprar el item finalmente o no
                    if answer == "Yes":
                        self.message_exchange(item, selected_user, usuarios)
                    elif answer == "No":
                        return
                else:
                    print("No tienes suficiente dinero para comprar esto")
                    return

    def message_exchange(self, item, selected_user, usuarios):
        # Se hace el intercambio de items y dinero una vez hecha la compra
        self.user.get("Storage").append(item)
        selected_user.get("Shop").remove(item)
        selected_user["Money"] += item['Value']
        self.user["Money"] -= int(self.send_message(str(item['Value'])))
        print("Item bought correctly!! Check your storage to see it.")

        # Se crea la clave simetrica Chacha y se hace el intercambio de claves
        keys = self.open_json('users_key.json')
        datos_asociados = self.user.get("Usuario") + selected_user.get("Usuario")
        aad = datos_asociados.encode('utf-8')
        key = ChaCha20Poly1305.generate_key()
        chacha = ChaCha20Poly1305(key)
        nonce = os.urandom(12)
        self.key_interchange(aad, nonce, chacha, keys)

        for i in keys:
            if i.get("User") == "System":
                system = i

        # Se envian los certificados mutuamente y se comprueban entre ellos
        print("Envio certificados del sistema")
        cert = self.send_message(system.get("Certificate"))
        cert1 = self.send_message(system.get("Cert_Level_1"))
        cert2 = self.send_message(system.get("Cert_Level_2"))

        found_c, found_c1, found_c2 = False, False, False

        for i in keys:
            if i.get("User") == "System" and i.get("Certificate") == cert:
                found_c = True
            if i.get("User") == "Sys_admim" and i.get("Certificate") == cert1:
                found_c1 = True
            if i.get("User") == "Prime_admin" and i.get("Certificate") == cert2:
                found_c2 = True

        if not found_c and found_c1 and found_c2:
            print("Los certificados no coinciden")
            return
        print("Certificados del sistema comprobados")

        print("Envio certificados del usuario")
        cert = self.send_message(self.certificate)
        cert1 = self.send_message(self.certificate_1)
        cert2 = self.send_message(self.certificate_2)

        found_c, found_c1, found_c2 = False, False, False

        for i in keys:
            if i.get("User") == self.user.get("Usuario") and i.get("Certificate") == cert:
                found_c = True
            if i.get("User") == "User_admim" and i.get("Certificate") == cert1:
                found_c1 = True
            if i.get("User") == "Prime_admin" and i.get("Certificate") == cert2:
                found_c2 = True

        # Si los certificados no coinciden salta error y no realiza la compra
        if not found_c and found_c1 and found_c2:
            print("Los certificados no coinciden")
            return
        print("Certificados del usuario comprobados")
        print("Transaccion producida sin errores")

        self.message_encryption(selected_user, item)

        self.update_from_json(usuarios, self.user)
        self.update_from_json(usuarios, selected_user)
        self.update_json('users_info.json', usuarios)

    def message_encryption(self, receiver, item):
        # Crea el mensaje que se le envia al vendedor sobre su producto comprado junto a la llave chacha y al nonce
        data = f"The user {self.user.get('Usuario')} just bought something from your shop. He has bought the item {item['Type']} for {item['Value']} coins. The coins have been added to your purse."
        msg = data.encode('utf-8')
        datos_asociados = self.user.get("Usuario") + receiver.get("Usuario")
        aad = datos_asociados.encode('utf-8')
        key = ChaCha20Poly1305.generate_key()
        chacha = ChaCha20Poly1305(key)
        nonce = os.urandom(12)

        # Encripta el mensaje a enviar
        print("Encrypting message. Please wait...")
        cyphertext = chacha.encrypt(nonce, msg, aad)

        # Pone en formato util las claves privadas y publicas del sistema, hashea el mensaje y lo firma
        print("Creating signatures. Please wait...")
        priv_key_bytes = base64.b64decode(self.private_key)
        user_priv_key = serialization.load_pem_private_key(priv_key_bytes, password=None)
        pub_key_bytes = base64.b64decode(self.public_key)
        user_pub_key = serialization.load_pem_public_key(pub_key_bytes)
        salt = os.urandom(16)
        msg_hash = self.user_authentication(str(cyphertext).encode('utf-8'), salt).encode('utf-8')
        msg_hash_signed = user_priv_key.sign(msg_hash, padding.PKCS1v15(), hashes.SHA256())

        # Envia el mensaje
        print("Sending message. Please wait...")
        message = [cyphertext, msg_hash_signed]
        cyphertext = message[0]
        msg_hash_signed = message[1]

        # Recibe el mensaje y comprueba la firma y el hash
        try:
            print("Receiving message. Please wait...")
            print("Decrypting message. Please wait...")
            msg_hash = self.user_authentication(str(cyphertext).encode('utf-8'), salt).encode('utf-8')
            print("Comparing signatures. Please wait...")
            user_pub_key.verify(
                msg_hash_signed,
                msg_hash,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            # Si sale correctamente guarda el mensaje en el buzon del vendedor y finaliza
            print("Todo ha sido comprobado correctamente. Felicidades la compra se ha realizado con exito!")
            plaintext = chacha.decrypt(nonce, cyphertext, aad).decode('utf-8')
            receiver.get("Messages").append(plaintext)
        except Exception as e:
            print("Error de autenticacion o de descifrado", str(e))

    def key_interchange(self, aad, nonce, chacha, keys):
        salt = os.urandom(16)
        chacha_key = [aad, nonce, chacha]
        chacha_key = str(chacha_key)
        # Accedemos a las claves privada y publica del sistema y del usuario que empieza el intercambio de claves
        for i in keys:
            if i.get("User") == "System":
                sys_public_key_bytes = base64.b64decode(i.get("Public_key"))
                sys_public_key = serialization.load_pem_public_key(sys_public_key_bytes)
                sys_private_key_bytes = base64.b64decode(i.get("Private_key"))
                sys_private_key = serialization.load_pem_private_key(sys_private_key_bytes, password=None)

        pub_key_bytes = base64.b64decode(self.public_key)
        user_pub_key = serialization.load_pem_public_key(pub_key_bytes)
        priv_key_bytes = base64.b64decode(self.private_key)
        user_priv_key = serialization.load_pem_private_key(priv_key_bytes, password = None)

        # Hacemos el hash de la clave simetrica y lo firmamos
        sym_key_hash = self.user_authentication(str(chacha_key).encode('utf-8'), salt).encode('utf-8')
        sym_key_hash_signed = user_priv_key.sign(sym_key_hash, padding.PKCS1v15(), hashes.SHA256())

        # Si envia la clave publica del sistema al usuario
        print("Enviamos la publica del sistema a usuario")
        system_public_key = base64.b64encode(sys_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )).decode()
        system_public_key = self.send_message(system_public_key)
        system_public_key = serialization.load_pem_public_key(base64.b64decode(system_public_key))

        # Si envia la clave publica del usuario al sistema
        print("Enviamos la publica del usuario a sistema")
        host_public_key = base64.b64encode(user_pub_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )).decode()
        host_public_key = self.send_message(host_public_key)
        host_public_key = serialization.load_pem_public_key(base64.b64decode(host_public_key))

        # Se encripta la clave simetrica y el hash firmado
        print("Encriptar clave simétrica")
        encrypted_chacha_key = system_public_key.encrypt(chacha_key.encode('utf-8'), padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                                                        algorithm=hashes.SHA256(), label=None))

        print("Encriptar firma digital")
        sym_key_hash_signed = base64.b64decode(self.send_message(base64.b64encode(sym_key_hash_signed).decode()))

        # Dividir y cifrar el hash firmado
        chunk_size = 190  # Tamaño máximo para RSA 2048 con OAEP y SHA-256
        encrypted_chunks = []
        for i in range(0, len(sym_key_hash_signed), chunk_size):
            chunk = sym_key_hash_signed[i:i + chunk_size]
            encrypted_chunk = system_public_key.encrypt(
                chunk,
                padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                             algorithm=hashes.SHA256(), label=None)
            )
            encrypted_chunks.append(encrypted_chunk)

        print("Enviar clave simétrica firmada")
        message = [encrypted_chacha_key, encrypted_chunks]
        encrypted_chacha_key = message[0]
        encrypted_chunks = message[1]

        print("Desencriptar clave simétrica")
        new_chacha_key = sys_private_key.decrypt(encrypted_chacha_key,
                                                 padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                                              algorithm=hashes.SHA256(), label=None)).decode()
        # Descifrar y unir los fragmentos
        print("Desencriptar firma digital")
        decrypted_chunks = []
        for chunk in encrypted_chunks:
            decrypted_chunk = sys_private_key.decrypt(
                chunk,
                padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                             algorithm=hashes.SHA256(), label=None)
            )
            decrypted_chunks.append(decrypted_chunk)
        new_hash_signed = b"".join(decrypted_chunks)

        sym_key_hash = self.user_authentication(str(new_chacha_key).encode('utf-8'), salt).encode('utf-8')

        try:
            # Verificación de la firma, el padding es random por lo tanto la primera y segunda derivacion son distintas
            host_public_key.verify(
                new_hash_signed,
                sym_key_hash,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            print("La firma es válida y corresponde el hash:", self.user.get("Usuario"))
        except Exception as e:
            print(f"La firma no es válida (puede que corresponda el hash): {str(e)}")

    def user_authentication(self, password, salt):
        # Empleamos PBKDF2HMAC, que crea kdf en base a:
        kdf = PBKDF2HMAC(
            # El algoritmo de hash SHA356
            algorithm=hashes.SHA256(),
            length=32,
            # El salt como factor aleatorio
            salt=salt,
            iterations=480000,
        )

        # Se crea el token
        token = base64.urlsafe_b64encode(kdf.derive(password))
        # Se decodifica a string
        token = token.decode("UTF-8")
        return token

    def sell(self, storage):
        sell_on = True
        # Entra en un bucle de compra
        while sell_on:
            n = 0
            # Pregunta por el item a comprar y lo compra si no hay ningun problema
            item_sell = self.send_message(input("Insert the number of item in list: "))
            if int(item_sell) > len(storage) + 1:
                exception = self.send_message("Number greater than storage capacity")
                print(exception)
            else:
                for item in storage:
                    n += 1
                    if n == int(item_sell):
                        self.user.get("Shop").append(item)
                        self.user.get("Storage").remove(item)
                sell_on = False

                usuarios = self.open_json('users_info.json')

                self.update_from_json(usuarios, self.user)
                self.update_json('users_info.json', usuarios)

    def open_json(self, file):
        # Abre el JSON y lo crea si no existe
        try:
            with open(file, 'r') as f:
                json_file = json.load(f)
        except json.decoder.JSONDecodeError:
            json_file = []
        except FileNotFoundError:
            json_file = []
        return json_file

    def update_from_json(self, user_list, user):
        # Actualiza la informacion del usuario en el JSON
        for i in user_list:
            if user.get("Usuario") == i.get("Usuario"):
                user_list.remove(i)
        user_list.append(user)

    def update_json(self, file, user_list):
        # Actualiza una parte del JSON
        with open(file, "w", encoding="utf-8") as f:
            json.dump(user_list, f, indent=2)

    def send_message(self, data):
        # Simula el envio de mensajes, cifrando y despues descifrando
        encrypt_data = self.session_key.encrypt(data.encode("UTF-8"))
        print(">>> ", encrypt_data)
        decrypt_data = self.session_key.decrypt(encrypt_data).decode("UTF-8")
        return decrypt_data