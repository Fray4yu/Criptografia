import base64
import json
import os
import re
from Session import Session
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.x509 import CertificateBuilder
from cryptography.hazmat.primitives.asymmetric import padding
import datetime
import random

class Home:
    def __init__(self):
        # Fernet key de la sesión de Home
        # Se genera al iniciar la sesión de Home
        self.home_key = self.create_key()
        # Key del chacha, nonce y aad para encriptar los JSONs
        self.chacha_key, self.nonce, self.aad = self.load_sys()

    def load_sys(self):
        # Carga en una variable el interior del json
        keysys = self.open_json('key_sys.json')
        # Si no existe o esta vacio, crea uno nuevo y le introduce la nueva key, nonce y aad
        if not keysys:
            self.create_sys(keysys)
        # Mete los datos en variables para luego devolverlas a los selfs del init para poder utilizarlos a lo largo del codigo
        for i in keysys:
            key = base64.b64decode(i.get("Key"))
            nonce = base64.b64decode(i.get("Nonce"))
            aad = i.get("Aad")
        return key, nonce, aad

    def create_sys(self, keysys):
        print("INICIALIZANDO SISTEMA")
        # Abre el JSON donde estan las llaves y crea la key del Chacha con su nonce
        users_key = self.open_json('users_key.json')
        key = ChaCha20Poly1305.generate_key()
        key = base64.b64encode(key).decode('utf-8')
        nonce = os.urandom(12)
        nonce = base64.b64encode(nonce).decode('utf-8')
        # Crea los datos del sistema
        data = {
            "Key": key,
            "Nonce": nonce,
            "Aad": None
        }
        keysys.append(data)
        # Crea los datos para cada autoridad y para el sistema
        print("Creando certificados y claves de autoridades...")
        for i in ["Prime_admin", "User_admin", "Sys_admin", "System"]:
            public, private = self.create_RSA_keys()
            if i == "Prime_admin":
                authority = "Prime_admin"
            elif i == "User_admin" or i == "Sys_admin":
                authority = "Prime_admin"
            elif i == "System":
                authority = "Sys_admin"
            user = {
                "User": i,
                "Public_key": public,
                "Private_key": private,
                "Authority": authority,
                "Certificate": None,
                "Cert_Level_1": None,
                "Cert_Level_2": None
            }
            users_key.append(user)
            self.update_json('users_key.json', users_key)
            # Crea el certificado para la entidad
            crt = self.csr_create(i, public, private, authority)
            cert_pem = crt.public_bytes(serialization.Encoding.PEM)
            cert = base64.b64encode(cert_pem).decode()
            user["Certificate"] = cert
            # Guarda los certificados de las autoridades superiores en los datos de las entidades que las tengan
            for i in users_key:
                if i.get("User") == user.get("User"):
                    users_key.remove(i)
                if i.get("User") == user.get("Authority") and user.get("User") != "Prime_admin":
                    user["Cert_Level_1"] = i["Certificate"]
                    user["Cert_Level_2"] = i["Cert_Level_1"]
            users_key.append(user)
            self.update_json('users_key.json', users_key)

        # Actualiza los datos del JSON
        self.update_json('key_sys.json', keysys)
        self.update_json('users_key.json', users_key)
        return

    def csr_create(self, username, host_pub_key, host_priv_key, authority):
        # Carga las claves publicas y privadas, del usuario que pide el certificado y de la autoridad, en el formato adecuado para su uso
        host_public_key_bytes = base64.b64decode(host_pub_key)
        host_public_key = serialization.load_pem_public_key(host_public_key_bytes)
        host_private_key_bytes = base64.b64decode(host_priv_key)
        host_private_key = serialization.load_pem_private_key(host_private_key_bytes, password = None)
        keys = self.open_json('users_key.json')
        for i in keys:
            if i.get("User") == authority:
                authority_pub_key_bytes = base64.b64decode(i.get("Public_key"))
                authority_pub_key = serialization.load_pem_public_key(authority_pub_key_bytes)
                authority_priv_key_bytes = base64.b64decode(i.get("Private_key"))
                authority_priv_key = serialization.load_pem_private_key(authority_priv_key_bytes, password = None)
        # Si el usuario es el Prime Admin no debe enviar nada ya que el certificado se lo hace a si mismo
        if username != "Prime_admin":
            self.key_interchange(username, host_public_key, host_private_key, authority_pub_key, authority_priv_key)

        # Crea el CSR (Certificate Signing Request), lo envia y se crea el certificado
        csr = x509.CertificateSigningRequestBuilder().subject_name(
            x509.Name([x509.NameAttribute(NameOID.GIVEN_NAME, username)])
        ).sign(host_private_key, hashes.SHA256())
        certificate = self.generate_certificate(csr, authority_priv_key)
        print("Generando certificado de: ", username)
        self.send_message(str(certificate))
        return certificate

    def generate_certificate(self, csr, ca_private_key):
        # Obtener los atributos del CSR
        subject = csr.subject  # El sujeto es el mismo que en el CSR
        public_key = csr.public_key()  # Clave pública del usuario

        # Crear el certificado. En este caso el emisor y el sujeto son los mismos
        builder = CertificateBuilder().subject_name(subject).issuer_name(subject)
        # Establecer la clave pública
        builder = builder.public_key(public_key)
        # Establecer el número de serie (debe ser único)
        builder = builder.serial_number(random.randint(0, 1000000000))
        # Establecer la validez del certificado
        builder = builder.not_valid_before(datetime.datetime.utcnow())
        builder = builder.not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=365))  # Válido por 1 año

        # Firmar el certificado con la clave privada de la CA
        certificate = builder.sign(
            ca_private_key,
            hashes.SHA256()
        )
        return certificate

    def key_interchange(self, username, host_public_key, host_private_key, authority_pub_key, authority_priv_key):
        # Crea la clave privada, la hashea y la firma
        key = Fernet.generate_key()
        salt = os.urandom(16)
        sym_key_hash = self.user_authentication(key, salt).encode('utf-8')
        sym_key_hash_signed = host_private_key.sign(sym_key_hash, padding.PKCS1v15(), hashes.SHA256())

        # Envia la clave publica del usuario que empieza el intercambio de claves
        print("Enviamos la publica del solicitante del certificado")
        host_public_key = base64.b64encode(host_public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )).decode()
        host_public_key = self.send_message(host_public_key)
        host_public_key = serialization.load_pem_public_key(base64.b64decode(host_public_key))

        # Encripta la clave simetrica y la desencripta, simulando el envio de la misma
        print("Enviamos clave simetrica")
        encrypted_sym_key = authority_pub_key.encrypt(key, padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                                                   algorithm=hashes.SHA256(), label=None))
        print(">>> ", encrypted_sym_key)
        sym_key = authority_priv_key.decrypt(encrypted_sym_key, padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()),
                                                          algorithm=hashes.SHA256(), label=None))

        # Encripta el hash firma de la clave siemtrica y lo desencripta, simulando el envio del mismo
        print("Enviamos hash firmado")
        sym_key_hash_signed = base64.b64decode(self.send_message(base64.b64encode(sym_key_hash_signed).decode()))

        sym_key_hash = self.user_authentication(sym_key, salt).encode('utf-8')

        try:
            # Verificación de la firma, el padding es random por lo tanto la primera y segunda derivacion son distintas
            host_public_key.verify(
                sym_key_hash_signed,
                sym_key_hash,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            print("La firma es válida y corresponde el hash:", username)
        except Exception as e:
            print(f"La firma no es válida (puede que corresponda el hash): {str(e)}")

    def encrypt_users(self, json_file):
        # Crea una nueva lista para el JSON encriptado
        encrypted_data = []
        # Para cada entrada del JSON, cada diccionario, lo pasa a texto y despues a bytes para cifrarlos
        # y meterlos a la nueva lista cifrados
        for entry in json_file:
            entry_json = str(entry).encode('UTF-8')
            chacha = ChaCha20Poly1305(self.chacha_key)
            cyphertext = chacha.encrypt(self.nonce, entry_json, self.aad)
            encrypted_entry = {
                "Data": base64.b64encode(cyphertext).decode('utf-8')
            }
            encrypted_data.append(encrypted_entry)
        # Finalmente devuelve la lista de datos cifrados
        return encrypted_data

    def decrypt_users(self, json_file):
        # Crea una nueva lista para el JSON desencriptado
        decrypted_data = []
        # Para cada entrada del JSON, cada diccionario, lo pasa a texto para despues descrifrarlo y
        # meterlo a la nueva lista descifrados
        for encrypted_entry in json_file:
            ciphertext = base64.b64decode(encrypted_entry["Data"])
            chacha = ChaCha20Poly1305(self.chacha_key)
            plaintext = chacha.decrypt(self.nonce, ciphertext, self.aad)
            plaintext_entry = eval(plaintext.decode('UTF-8'))
            decrypted_data.append(plaintext_entry)
        # Finalmente devuelve la lista de datos descifrados
        return decrypted_data

    def sign_up(self):
        # El usuario le dice al sistema su nombre
        usuario = self.send_message(input("Usuario: "))
        # Se comprueba que la información introducida es correcta
        if not re.match(r'^[A-Z][a-záéíóúñ]*$', usuario):
            print("Nombre inválido. El nombre debe contener solo letras (sin tildes) y la primera debe ser mayúscula.")
            return
        # El usuario le dice al sistema su contraseña
        contraseña = self.send_message(input("Contraseña: ")).encode("UTF-8")
        # Se comprueba que la contraseña es lo suficientemente segura
        password = contraseña.decode("UTF-8")
        if not (len(password) >= 12 and re.search(r'[A-Z]', password) and re.search(r'\d', password) and re.search(r'[!@#$%^&*(),.?":{}|<>]', password)):
            print("Contraseña inválida. Debe contener al menos 12 caracteres, una mayúscula, un número y un caracter especial para ser segura.")
            return

        # Se abre el json con la info de inicio de sesión de los usuarios
        usuarios = self.open_json('users_json.json')
        # Se desencripta su información
        usuarios = self.decrypt_users(usuarios)
        # Se abre el json con la info de los usuarios de la app
        info = self.open_json('users_info.json')
        users_key = self.open_json('users_key.json')

        # Se comprueba si en la BD existe ese usuario
        for i in usuarios:
            if usuario == i.get("Usuario"):
                print("Usuario ya existente")
                return

        # Se genera un salt, un número aleatorio de 16 bytes
        salt = os.urandom(16)
        #
        token = self.user_authentication(contraseña, salt)
        # Se decodifica el salt a string
        salt = base64.b64encode(salt).decode('utf-8')

        # Se crea la info de inicio de sesión del usuario
        user_auth = {
            "Usuario": usuario,
            "Token": token,
            "Salt": salt
        }
        # Se crea la info de las llaves y certificados del usuario
        authority = "User_admin"
        public, private = self.create_RSA_keys()
        user = {
            "User": usuario,
            "Public_key": public,
            "Private_key": private,
            "Authority": authority,
            "Certificate": None,
            "Cert_Level_1": None,
            "Cert_Level_2": None
        }
        users_key.append(user)
        self.update_json('users_key.json', users_key)
        # Crea el CSR (Certificate Signing Request), lo envia y se crea el certificado
        crt = self.csr_create(usuario, public, private, authority)
        cert_pem = crt.public_bytes(serialization.Encoding.PEM)
        cert = base64.b64encode(cert_pem).decode()
        user["Certificate"] = cert
        # Guarda los certificados de las autoridades superiores en los datos de las entidades que las tengan
        for i in users_key:
            if i.get("User") == user.get("User"):
                users_key.remove(i)
            if i.get("User") == user.get("Authority"):
                user["Cert_Level_1"] = i["Certificate"]
                user["Cert_Level_2"] = i["Cert_Level_1"]
        users_key.append(user)
        self.update_json('users_key.json', users_key)

        # Se crea la info del usuario en la app
        user_info = {
            "Usuario": usuario,
            "Storage": [],
            "Shop": [],
            "Money": 2000,
            "Messages": []
        }

        # Introduce los datos en los JSONs
        usuarios.append(user_auth)
        info.append(user_info)
        # Imprime los datos descifrados
        print(usuarios)

        # Imprime los datos cifrados, los vuelve a encriptar y actualiza los JSONs
        usuarios = self.encrypt_users(usuarios)
        print(usuarios)
        self.update_json("users_json.json", usuarios)
        self.update_json("users_info.json", info)

        print("Registro completado correctamente")

        return

    def log_in(self):
        # El usuario le dice al sistema su nombre
        usuario = self.send_message(input("Usuario: "))
        # El usuario le dice al sistema su contraseña
        contraseña = self.send_message(input("Contraseña: ")).encode("UTF-8")

        # Se abre el json con la info de inicio de sesión de los usuarios
        usuarios = self.open_json('users_json.json')
        # Se desencripta su información
        usuarios = self.decrypt_users(usuarios)
        # Se abre el json con la info de los usuarios de la app
        info = self.open_json('users_info.json')

        # Si no hay ningún usuario registrado
        if len(usuarios) == 0:
            print("Usuario no existente")
            return

        # No hemos encontrado al usuario
        found = False

        # Se busca al usuario en la BD de los datos de inicio de sesión
        for i in usuarios:
            # Si se encuentra
            if usuario == i.get("Usuario"):
                # Cogemos su token
                user_token = i.get("Token")
                # Cogemos su salt
                user_salt = i.get("Salt")
                # Decimos que lo hemos encontrado
                found = True
        # Se busca al usuario en la BD de los datos de inicio de sesión
        for i in info:
            if usuario == i.get("Usuario"):
                user = i

        # Si no se ha encontrado
        if not found:
            print("Usuario no existente")
            return

        salt = base64.b64decode(user_salt)
        token = self.user_authentication(contraseña, salt)

        if token == user_token:
            print("Bienvenido, %s!!!" % usuario)
            keys = self.open_json('users_key.json')
            for i in keys:
                if i.get("User") == user.get("Usuario"):
                    user_key = i
            session = Session(user, user_key, self.create_key())
            session.session_on()
        else:
            print("Contraseña erronea")
        return

    # Función de la autenticación de usuario
    def user_authentication(self, password, salt):
        # Empleamos PBKDF2HMAC, que crea kdf en base a:
        kdf = PBKDF2HMAC(
            # El algoritmo de hash SHA356
            algorithm=hashes.SHA256(),
            length=32,
            # El salt como factor aleatorio
            salt=salt,
            iterations=480000,
        )

        # Se crea el token
        token = base64.urlsafe_b64encode(kdf.derive(password))
        # Se decodifica a string
        token = token.decode("UTF-8")
        return token

    def create_RSA_keys(self):
        # Crea las claves privada y publica y las envia de forma que se puedan almacenar
        private = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )
        public = private.public_key()

        private_pem = private.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        )

        public_pem = public.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )

        return base64.b64encode(public_pem).decode(), base64.b64encode(private_pem).decode()

    def open_json(self, file):
        # Se abre el json dado
        try:
            with open(file, 'r') as f:
                json_file = json.load(f)
        except FileNotFoundError:
            # Si no existe, se crea una lista vacía
            json_file = []
        return json_file

    def update_json(self, file, user_list):
        # Modifica el json dado con la info de la lista dada
        with open(file, "w", encoding="utf-8") as f:
            json.dump(user_list, f, indent=2)

    def create_key(self):
        # Se genera una Fernet key
        key = Fernet.generate_key()
        f_key = Fernet(key)
        return f_key

    # Función para enviar mensajes con sistema
    def send_message(self, data):
        # Encriptación del mensaje con la key de Home
        encrypt_data = self.home_key.encrypt(data.encode("UTF-8"))
        print(">>> ", encrypt_data)
        # Desencriptación del mensaje
        decrypt_data = self.home_key.decrypt(encrypt_data).decode("UTF-8")
        return decrypt_data

