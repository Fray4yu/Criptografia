from Home import Home

def main():
    # Se inicia la aplicación
    app_on = True
    print("Bienvenido a la aplicación!!!")
    while app_on:
        # Se accede a la pestaña de Home
        home = Home()
        # Se le pide al usuario que elija una opción
        option = input("Log In/Sign Up/Close: ")
        if option == "Sign Up":
            # El usuario intenta registrarse
            home.sign_up()
        elif option == "Log In":
            # El usuario intenta iniciar sesión
            home.log_in()
        elif option == "Close":
            # El usuario sale de la app
            app_on = False
            print("Saliendo de la aplicación...")
        else:
            # No ha escogido una opción válida
            print("Error: opción invalida. Prueba a escribir los caracteres correctamente")
    return

if __name__ == "__main__":
    main()